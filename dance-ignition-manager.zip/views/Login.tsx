
import React, { useState } from 'react';
import { DB, Judge, UserRole } from '../types';

interface LoginProps {
  type: UserRole;
  db: DB;
  onLogin: (role: UserRole, user?: Judge) => void;
  onCancel: () => void;
}

const Login: React.FC<LoginProps> = ({ type, db, onLogin, onCancel }) => {
  const [pin, setPin] = useState('');
  const [id, setId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (type === 'ADMIN') {
      if (pin === '0000') {
        onLogin('ADMIN');
      } else {
        alert("Incorrect Admin PIN (hint: 0000)");
      }
    } else if (type === 'JUDGE') {
      const judge = db.judges.find(j => j.pin === pin && (id === '' || j.id === id));
      if (judge) {
        onLogin('JUDGE', judge);
      } else {
        alert("Invalid credentials. Please contact Administrator.");
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 overflow-hidden relative">
      {/* Background decoration */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-orange-600/10 rounded-full blur-[100px]"></div>
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-purple-600/10 rounded-full blur-[100px]"></div>

      <div className="max-w-md w-full glass rounded-[3rem] p-12 border border-white/10 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.6)] relative z-10 animate-in zoom-in-95 duration-500">
        <div className="text-center mb-12">
          <div className="w-16 h-16 btn-primary rounded-2xl flex items-center justify-center mx-auto mb-8 font-black text-3xl brand-font italic shadow-2xl">DI</div>
          <div className="inline-block px-6 py-1 glass-orange text-orange-500 text-[10px] font-black tracking-[0.4em] uppercase rounded-full mb-6">
            Secure Terminal
          </div>
          <h2 className="text-5xl font-black brand-font text-white uppercase italic leading-none">{type} AUTH</h2>
          <p className="text-slate-500 text-[10px] uppercase font-bold tracking-widest mt-4">Authorized Personnel Only</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {type === 'JUDGE' && (
             <div className="space-y-3">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Judge Identifier</label>
              <input 
                className="w-full bg-slate-800/50 border-2 border-slate-800 rounded-2xl px-6 py-4 outline-none focus:border-purple-500 text-white font-mono shadow-inner"
                placeholder="EX: J123"
                value={id}
                onChange={e => setId(e.target.value.toUpperCase())}
              />
            </div>
          )}
          <div className="space-y-3">
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Secure Access PIN</label>
            <input 
              type="password"
              className="w-full bg-slate-800/50 border-2 border-slate-800 rounded-2xl px-6 py-4 outline-none focus:border-orange-500 text-white tracking-[1em] text-center text-3xl shadow-inner"
              placeholder="••••"
              value={pin}
              onChange={e => setPin(e.target.value)}
              maxLength={type === 'ADMIN' ? 4 : 10}
            />
          </div>

          <button type="submit" className="btn-primary w-full py-5 text-white font-black rounded-2xl shadow-2xl transition-all transform hover:-translate-y-1 text-lg brand-font tracking-widest uppercase mt-8">
            Access System
          </button>
          
          <button type="button" onClick={onCancel} className="w-full text-[10px] font-bold text-slate-500 hover:text-white transition-colors uppercase tracking-[0.2em]">
            Cancel Authentication
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
