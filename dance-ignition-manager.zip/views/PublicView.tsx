
import React, { useState, useEffect, useMemo } from 'react';
import { DB, Participant, CompetitionEvent } from '../types';

interface PublicViewProps {
  db: DB;
  setDb: (newDb: Partial<DB>) => void;
}

const PublicView: React.FC<PublicViewProps> = ({ db, setDb }) => {
  const [view, setView] = useState<'HOME' | 'REGISTER' | 'CHECK_SCORE' | 'ARCHIVE' | 'STAGE' | 'LEADERBOARD'>('HOME');
  const [regData, setRegData] = useState<Record<string, string>>({});
  const [selectedCategory, setSelectedCategory] = useState('');
  const [searchCode, setSearchCode] = useState('');
  const [foundParticipant, setFoundParticipant] = useState<Participant | null>(null);
  const [timeLeft, setTimeLeft] = useState<{ d: number; h: number; m: number; s: number } | null>(null);

  const primaryEvent = useMemo(() => db.events.find(e => e.isPrimary) || null, [db.events]);

  useEffect(() => {
    if (!primaryEvent || !primaryEvent.isCountdownActive) {
      setTimeLeft(null);
      return;
    }
    const interval = setInterval(() => {
      const target = new Date(primaryEvent.eventDate).getTime();
      const now = new Date().getTime();
      const distance = target - now;
      if (distance < 0) {
        setTimeLeft(null);
        clearInterval(interval);
      } else {
        setTimeLeft({
          d: Math.floor(distance / (1000 * 60 * 60 * 24)),
          h: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          m: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          s: Math.floor((distance % (1000 * 60)) / 1000),
        });
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [primaryEvent?.eventDate, primaryEvent?.isCountdownActive]);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCategory) return;
    const uniqueCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    const newParticipant: Participant = {
      id: uniqueCode,
      name: regData[db.settings.registrationFields.find(f => f.label.toLowerCase().includes('name'))?.id || ''] || 'Guest',
      phoneNumber: regData[db.settings.registrationFields.find(f => f.label.toLowerCase().includes('phone'))?.id || ''] || 'N/A',
      category: selectedCategory,
      ageGroup: 'General',
      status: 'PENDING',
      submissions: [],
      registrationDate: Date.now(),
      customData: regData
    };
    setDb({ participants: [...db.participants, newParticipant] });
    alert(`Registration Successful! Code: ${uniqueCode}`);
    setView('HOME');
  };

  const handleSearch = () => {
    const p = db.participants.find(p => p.id === searchCode.toUpperCase());
    setFoundParticipant(p || null);
    if (!p) alert("Participant code not recognized.");
  };

  const currentOnStage = db.participants.find(p => p.id === db.settings.highlightedParticipantId);

  const renderMedia = (ev: CompetitionEvent) => {
    if (ev.mediaType === 'NONE' || !ev.mediaUrl) return null;
    if (ev.mediaType === 'IMAGE') {
      return (
        <div className="max-w-5xl mx-auto mb-12 rounded-[3rem] overflow-hidden border-2 border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] transform hover:scale-[1.01] transition-transform">
          <img src={ev.mediaUrl} alt={ev.title} className="w-full h-[400px] object-cover" />
        </div>
      );
    }
    // Video handling...
    return null;
  };

  return (
    <div className="space-y-16 animate-in fade-in duration-1000">
      {view === 'HOME' && (
        <div className="space-y-20">
          {/* Hero Section */}
          <div className="relative py-24 px-6 text-center overflow-hidden rounded-[4rem] border border-white/5 group">
            <div className="absolute inset-0 z-0">
               <img 
                 src="https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=2070" 
                 className="w-full h-full object-cover opacity-20 transition-transform duration-1000 group-hover:scale-110" 
                 alt="Dance Background"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent"></div>
            </div>

            <div className="relative z-10 space-y-8 max-w-5xl mx-auto">
              <div className="inline-block px-6 py-2 glass-orange rounded-full text-[10px] font-black uppercase tracking-[0.4em] text-orange-500 mb-4 animate-pulse">
                Igniting the Stage Since 2025
              </div>
              <h2 className="brand-font text-8xl md:text-[12rem] mb-4 text-white uppercase tracking-tighter leading-none italic select-none">
                {db.settings.websiteName} <span className="text-orange-500 block md:inline">{db.settings.season}</span>
              </h2>
              <p className="text-xl text-slate-400 font-light max-w-2xl mx-auto uppercase tracking-widest leading-relaxed">
                Experience the raw energy of modern movement. <span className="text-white font-bold">Register today</span> and claim your place in the archives.
              </p>
              
              <div className="flex flex-wrap justify-center gap-6 pt-8">
                <button onClick={() => setView('STAGE')} className="btn-primary px-12 py-5 text-white font-black rounded-full uppercase tracking-widest text-lg brand-font flex items-center gap-3 group">
                  <span className="w-3 h-3 bg-white rounded-full animate-ping"></span>
                  Live Stage
                </button>
                <button onClick={() => setView('REGISTER')} className="px-12 py-5 bg-white text-slate-950 font-black rounded-full uppercase tracking-widest text-lg brand-font hover:bg-orange-500 hover:text-white transition-all transform hover:-translate-y-1 shadow-2xl">
                  Register
                </button>
                <button onClick={() => setView('CHECK_SCORE')} className="glass px-12 py-5 text-white font-black rounded-full uppercase tracking-widest text-lg brand-font hover:bg-white/10 transition-all transform hover:-translate-y-1">
                  My Results
                </button>
              </div>
            </div>
          </div>

          {/* Ad & Media Section */}
          {primaryEvent && (
            <div className="max-w-6xl mx-auto px-4 space-y-12">
               {primaryEvent.isAdActive && (
                 <div className="glass-orange p-1 px-8 rounded-full text-center">
                    <p className="text-orange-500 text-sm font-bold uppercase tracking-[0.2em]">{primaryEvent.adText}</p>
                 </div>
               )}
               {renderMedia(primaryEvent)}
            </div>
          )}

          {/* Countdown Section */}
          {timeLeft && (
             <div className="max-w-5xl mx-auto px-4">
               <div className="text-center mb-8">
                  <h3 className="heading-font text-sm font-bold uppercase tracking-[0.5em] text-slate-500">Event Begins In</h3>
               </div>
               <div className="flex justify-center gap-4 md:gap-12">
                 {[ 
                   { v: timeLeft.d, l: 'Days' }, 
                   { v: timeLeft.h, l: 'Hours' }, 
                   { v: timeLeft.m, l: 'Mins' }, 
                   { v: timeLeft.s, l: 'Secs' } 
                 ].map(unit => (
                   <div key={unit.l} className="flex flex-col items-center group">
                     <div className="w-24 h-24 md:w-32 md:h-32 glass rounded-[2.5rem] flex items-center justify-center shadow-2xl group-hover:border-orange-500/50 transition-all border border-white/5">
                       <span className="brand-font text-5xl md:text-7xl text-orange-500">{unit.v.toString().padStart(2, '0')}</span>
                     </div>
                     <span className="text-[10px] uppercase font-black text-slate-600 mt-4 tracking-[0.3em] group-hover:text-orange-400 transition-colors">{unit.l}</span>
                   </div>
                 ))}
               </div>
             </div>
          )}
        </div>
      )}

      {view === 'REGISTER' && (
        <div className="max-w-2xl mx-auto glass p-12 md:p-16 rounded-[4rem] border border-white/10 shadow-2xl animate-in zoom-in-95 duration-500">
          <button onClick={() => setView('HOME')} className="text-slate-500 mb-8 hover:text-white transition-colors flex items-center gap-2 font-bold uppercase text-xs tracking-widest">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            Return
          </button>
          <h2 className="text-6xl font-black mb-12 brand-font tracking-tight text-white uppercase italic leading-none">
            Join the <span className="text-orange-500">Ignition</span>
          </h2>
          <form onSubmit={handleRegister} className="space-y-8">
            {db.settings.registrationFields.map(field => (
              <div key={field.id} className="space-y-3">
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">{field.label} {field.required && <span className="text-orange-500">*</span>}</label>
                <input 
                  required={field.required} 
                  type={field.type} 
                  className="w-full bg-slate-900/50 border-2 border-slate-800 rounded-3xl px-8 py-5 text-sm focus:border-orange-500 outline-none transition-all text-white shadow-inner font-semibold" 
                  value={regData[field.id] || ''} 
                  onChange={e => setRegData({...regData, [field.id]: e.target.value})} 
                  placeholder={`Enter ${field.label}...`}
                />
              </div>
            ))}
            <div className="space-y-3">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Category Selection *</label>
              <select 
                required 
                className="w-full bg-slate-900/50 border-2 border-slate-800 rounded-3xl px-8 py-5 text-sm focus:border-orange-500 outline-none appearance-none font-bold text-white shadow-inner cursor-pointer" 
                value={selectedCategory} 
                onChange={e => setSelectedCategory(e.target.value)}
              >
                <option value="">Choose your discipline...</option>
                {db.settings.categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <button type="submit" className="btn-primary w-full py-6 rounded-[2.5rem] font-black mt-8 text-white uppercase tracking-[0.2em] text-xl brand-font shadow-2xl">
              Confirm Registration
            </button>
          </form>
        </div>
      )}

      {view === 'CHECK_SCORE' && (
        <div className="max-w-2xl mx-auto space-y-8 animate-in slide-in-from-bottom-8 duration-500">
          <div className="glass p-12 rounded-[3.5rem] border border-white/10 shadow-2xl">
            <button onClick={() => setView('HOME')} className="text-slate-500 mb-8 hover:text-white transition-colors flex items-center gap-2 font-bold uppercase text-xs tracking-widest">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
              Home
            </button>
            <h2 className="text-5xl font-black mb-8 brand-font tracking-tight text-white uppercase italic">Performer Dashboard</h2>
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Enter Unique Performer Code</label>
                <div className="flex gap-4">
                   <input 
                     className="flex-1 bg-slate-900/50 border-2 border-slate-800 rounded-3xl px-8 py-5 text-sm font-mono text-orange-500 outline-none focus:border-orange-500 transition-all shadow-inner" 
                     placeholder="EX: A7B2C9"
                     value={searchCode}
                     onChange={e => setSearchCode(e.target.value.toUpperCase())}
                   />
                   <button onClick={handleSearch} className="btn-primary px-8 rounded-3xl font-black uppercase text-xs tracking-widest">Find</button>
                </div>
              </div>
            </div>

            {foundParticipant && (
              <div className="mt-12 p-8 bg-slate-950/50 rounded-3xl border border-white/5 animate-in zoom-in-95 duration-500">
                 <div className="flex justify-between items-start mb-6 border-b border-slate-800 pb-6">
                    <div>
                      <p className="text-[10px] text-orange-500 font-black uppercase tracking-widest mb-1">Official Results for</p>
                      <h3 className="text-3xl font-black brand-font text-white">{foundParticipant.name}</h3>
                      <span className="text-[10px] bg-slate-800 px-3 py-1 rounded-full text-slate-400 font-bold uppercase mt-2 inline-block tracking-tighter">{foundParticipant.category}</span>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] text-slate-500 uppercase font-black">Code</p>
                       <p className="text-2xl font-black brand-font text-orange-500">{foundParticipant.id}</p>
                    </div>
                 </div>
                 
                 {foundParticipant.submissions.length > 0 ? (
                   <div className="space-y-4">
                      <div className="bg-orange-600/10 p-4 rounded-2xl border border-orange-500/20 text-center">
                        <p className="text-[10px] text-orange-500 font-black uppercase tracking-widest mb-1">Status</p>
                        <p className="text-2xl font-black brand-font text-white">{foundParticipant.status}</p>
                      </div>
                      <p className="text-center text-xs text-slate-500 mt-4 italic font-medium">Full scorecard is available via the Admin desk. Your performance is officially in the books.</p>
                   </div>
                 ) : (
                   <div className="text-center py-8 glass-orange rounded-2xl">
                     <p className="text-orange-500 font-bold uppercase tracking-widest text-xs">Evaluation Pending</p>
                     <p className="text-slate-400 text-[10px] mt-1 font-medium italic">Our judges are currently reviewing your set.</p>
                   </div>
                 )}
              </div>
            )}
          </div>
        </div>
      )}

      {view === 'STAGE' && (
        <div className="max-w-5xl mx-auto space-y-12 animate-in fade-in duration-500 text-center py-12">
          <button onClick={() => setView('HOME')} className="text-slate-500 hover:text-white transition-colors flex items-center gap-2 font-bold uppercase text-xs tracking-widest mx-auto">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            Live Feed
          </button>
          
          <div className="relative group">
            <div className="absolute inset-0 bg-orange-600/20 rounded-[5rem] blur-[80px] group-hover:blur-[120px] transition-all opacity-40"></div>
            <div className="relative glass p-20 md:p-32 rounded-[5rem] border-4 border-orange-500 shadow-[0_0_100px_rgba(255,95,31,0.2)] space-y-10 overflow-hidden">
               <div className="absolute top-0 left-0 bg-orange-600 px-10 py-3 text-[10px] font-black uppercase tracking-[0.5em] text-white shadow-2xl">Spotlight On</div>
               {currentOnStage ? (
                 <>
                   <div className="space-y-4">
                     <h3 className="text-8xl md:text-[12rem] font-black brand-font text-white leading-none italic uppercase tracking-tighter">
                       {currentOnStage.name}
                     </h3>
                     <div className="h-2 w-48 bg-orange-600 mx-auto rounded-full"></div>
                   </div>
                   <p className="text-orange-500 font-black uppercase tracking-[0.3em] text-2xl heading-font">{currentOnStage.category}</p>
                   <div className="text-6xl font-mono text-slate-800 font-black opacity-30 select-none">ID: {currentOnStage.id}</div>
                 </>
               ) : (
                 <div className="py-20 space-y-6">
                   <h3 className="text-6xl font-black text-slate-800 uppercase brand-font tracking-widest">Stage Cleared</h3>
                   <div className="flex justify-center gap-3">
                      <div className="w-3 h-3 bg-slate-800 rounded-full animate-bounce"></div>
                      <div className="w-3 h-3 bg-slate-800 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                      <div className="w-3 h-3 bg-slate-800 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                   </div>
                 </div>
               )}
            </div>
          </div>
          
          <div className="max-w-md mx-auto">
             <div className="glass p-6 rounded-3xl border border-white/5 flex items-center justify-between">
                <div className="text-left">
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Up Next</p>
                  <p className="text-lg font-black brand-font text-white">{db.participants.find(p => p.id === db.settings.nextParticipantId)?.name || 'Lineup Pending'}</p>
                </div>
                <div className="w-12 h-12 glass-orange rounded-full flex items-center justify-center text-orange-500">
                   <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 5l7 7m0 0l-7 7m7-7H3"/></svg>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PublicView;
