
import React, { useState, useMemo, useEffect } from 'react';
import { DB, Participant, Judge, WinnerArchive, CompetitionEvent } from '../types';

interface AdminViewProps {
  db: DB;
  setDb: (newDb: Partial<DB>) => void;
}

const AdminView: React.FC<AdminViewProps> = ({ db, setDb }) => {
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'PARTICIPANTS' | 'RESULTS' | 'JUDGES' | 'SETTINGS' | 'ARCHIVES' | 'EVENTS'>('DASHBOARD');
  const [editingParticipant, setEditingParticipant] = useState<Participant | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [newYear, setNewYear] = useState('');
  const [flashMessage, setFlashMessage] = useState<string | null>(null);

  useEffect(() => {
    if (flashMessage) {
      const timer = setTimeout(() => setFlashMessage(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [flashMessage]);

  const calculateTotal = (p: Participant) => {
    if (p.submissions.length === 0) return 0;
    const judgeTotals = p.submissions.map(s => {
      if (db.settings.scoringFormula === 'WEIGHTED AVERAGE') {
        let totalWeighted = 0, totalWeights = 0;
        db.settings.subjects.forEach(sub => {
          const weight = db.settings.subjectWeights[sub.id] || 1;
          totalWeighted += (s.scores[sub.id] || 0) * weight;
          totalWeights += weight;
        });
        return totalWeights > 0 ? totalWeighted / totalWeights : 0;
      }
      return Object.values(s.scores).reduce((a, b) => a + b, 0);
    });
    switch (db.settings.scoringFormula) {
      case 'SUM': return judgeTotals.reduce((a, b) => a + b, 0);
      case 'AVERAGE':
      case 'WEIGHTED AVERAGE': return judgeTotals.reduce((a, b) => a + b, 0) / judgeTotals.length;
      case 'HIGHEST SCORE': return Math.max(...judgeTotals);
      default: return 0;
    }
  };

  const filteredParticipants = useMemo(() => {
    return db.participants.filter(p => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = p.name.toLowerCase().includes(searchLower) || p.id.toLowerCase().includes(searchLower) || p.phoneNumber.toLowerCase().includes(searchLower);
      const matchesCategory = categoryFilter === 'ALL' || p.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [db.participants, searchTerm, categoryFilter]);

  const stats = useMemo(() => {
    const total = db.participants.length;
    const completed = db.participants.filter(p => p.status === 'COMPLETED').length;
    const pending = db.participants.filter(p => p.status === 'PENDING').length;
    return { total, completed, pending };
  }, [db.participants]);

  const handleUpdateParticipant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingParticipant) return;
    const updated = db.participants.map(p => p.id === editingParticipant.id ? editingParticipant : p);
    setDb({ participants: updated });
    setEditingParticipant(null);
    setFlashMessage(`Updated ${editingParticipant.name}`);
  };

  const handleStatusChange = (id: string, newStatus: Participant['status']) => {
    const updated = db.participants.map(p => p.id === id ? { ...p, status: newStatus } : p);
    setDb({ participants: updated });
  };

  const setStage = (id: string | null, type: 'NOW' | 'NEXT') => {
    const participant = db.participants.find(p => p.id === id);
    const name = participant ? participant.name : 'Stage';
    if (type === 'NOW') {
      const updatedParticipants = db.participants.map(p => {
        if (id && p.id === id) return { ...p, status: 'ON_STAGE' as const };
        if (!id && p.status === 'ON_STAGE') return { ...p, status: 'PENDING' as const };
        return p;
      });
      setDb({ 
        participants: updatedParticipants,
        settings: { ...db.settings, highlightedParticipantId: id } 
      });
      setFlashMessage(id ? `${name} set as ON STAGE` : 'Stage Highlight Cleared');
    } else {
      setDb({ settings: { ...db.settings, nextParticipantId: id } });
      setFlashMessage(id ? `FLASH MESSAGE: Next is ${name}` : 'Rotation cleared');
    }
  };

  const addEvent = () => {
    const newEv: CompetitionEvent = {
      id: Math.random().toString(36).substr(2, 6).toUpperCase(),
      title: 'New Event Title',
      adText: 'Event Advertisement Text...',
      eventDate: new Date().toISOString(),
      isAdActive: false,
      isCountdownActive: false,
      isPrimary: db.events.length === 0,
      mediaType: 'NONE',
      mediaUrl: ''
    };
    setDb({ events: [...db.events, newEv] });
  };

  const toggleEventActive = (id: string, field: 'isAdActive' | 'isCountdownActive' | 'isPrimary') => {
    const updated = db.events.map(ev => {
      if (field === 'isPrimary') return { ...ev, isPrimary: ev.id === id };
      if (ev.id === id) return { ...ev, [field]: !ev[field] };
      return ev;
    });
    setDb({ events: updated });
  };

  const updateEventField = (id: string, field: keyof CompetitionEvent, value: any) => {
    const updated = db.events.map(ev => ev.id === id ? { ...ev, [field]: value } : ev);
    setDb({ events: updated });
  };

  const deleteEvent = (id: string) => {
    if (!confirm('Remove this event announcement?')) return;
    setDb({ events: db.events.filter(e => e.id !== id) });
  };

  const handleImageUpload = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateEventField(id, 'mediaUrl', reader.result as string);
        updateEventField(id, 'mediaType', 'IMAGE');
      };
      reader.readAsDataURL(file);
    }
  };

  const getStatusRowClass = (p: Participant) => {
    const isHighlighted = p.id === db.settings.highlightedParticipantId;
    if (isHighlighted) return 'bg-orange-600/10 border-l-4 border-l-orange-500 shadow-[inset_0_0_20px_rgba(234,88,12,0.1)]';
    switch(p.status) {
      case 'ON_STAGE': return 'bg-orange-500/5 border-l-4 border-l-orange-500';
      case 'COMPLETED': return 'bg-green-500/5 border-l-4 border-l-green-500';
      default: return 'bg-slate-900/40 border-l-4 border-l-transparent';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500 relative">
      {flashMessage && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-4 duration-300 pointer-events-none">
          <div className="bg-orange-600 text-white px-8 py-4 rounded-full shadow-2xl shadow-orange-500/40 font-black brand-font tracking-widest flex items-center gap-4 border-2 border-white/20">
            <div className="w-2.5 h-2.5 bg-white rounded-full animate-ping"></div>
            <span className="text-lg">{flashMessage}</span>
          </div>
        </div>
      )}

      <nav className="flex gap-2 overflow-x-auto pb-2 border-b border-slate-800">
        {['DASHBOARD', 'PARTICIPANTS', 'EVENTS', 'RESULTS', 'JUDGES', 'SETTINGS', 'ARCHIVES'].map(t => (
          <button key={t} onClick={() => setActiveTab(t as any)} className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${activeTab === t ? 'bg-orange-600 text-white shadow-lg shadow-orange-500/20' : 'text-slate-500 bg-slate-800/50 hover:text-white'}`}>{t}</button>
        ))}
      </nav>

      {activeTab === 'DASHBOARD' && (
        <div className="space-y-8">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg text-center"><p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total</p><p className="text-3xl font-black">{stats.total}</p></div>
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg text-center"><p className="text-[10px] font-bold text-green-500 uppercase tracking-widest">Done</p><p className="text-3xl font-black text-green-500">{stats.completed}</p></div>
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg text-center"><p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest">Wait</p><p className="text-3xl font-black text-orange-500">{stats.pending}</p></div>
          </div>
          <div className="bg-slate-900 p-8 rounded-[2rem] border-2 border-orange-500/50 shadow-2xl space-y-8">
            <h3 className="text-2xl font-black brand-font uppercase text-white tracking-widest border-b border-slate-800 pb-4">Stage Control</h3>
            <div className="space-y-6">
              <div>
                <label className="text-[10px] font-black text-orange-500 uppercase tracking-widest block mb-2">NOW PERFORMING</label>
                <div className="flex gap-2">
                  <select className="flex-1 bg-slate-950 border-2 border-slate-800 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-orange-500" value={db.settings.highlightedParticipantId || ''} onChange={e => setStage(e.target.value || null, 'NOW')}>
                    <option value="">-- Clear --</option>
                    {db.participants.map(p => <option key={p.id} value={p.id}>{p.name} (#{p.id})</option>)}
                  </select>
                  {db.settings.highlightedParticipantId && <button onClick={() => setStage(null, 'NOW')} className="px-6 bg-red-600/10 text-red-500 border border-red-500/20 rounded-2xl text-[10px] font-black uppercase">Off</button>}
                </div>
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-2">UP NEXT</label>
                <select className="w-full bg-slate-950 border-2 border-slate-800 p-4 rounded-2xl text-sm font-bold text-slate-400 outline-none" value={db.settings.nextParticipantId || ''} onChange={e => setStage(e.target.value || null, 'NEXT')}>
                  <option value="">-- None --</option>
                  {db.participants.map(p => <option key={p.id} value={p.id}>{p.name} (#{p.id})</option>)}
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'PARTICIPANTS' && (
        <div className="space-y-6">
          <input className="bg-slate-800 border border-slate-700 px-4 py-3 rounded-xl outline-none focus:ring-2 ring-orange-500 w-full text-sm text-white" placeholder="Search..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
             <table className="w-full text-left text-sm">
               <thead className="bg-slate-950 text-slate-600 font-bold uppercase text-[10px] tracking-widest border-b border-slate-800">
                 <tr><th className="px-6 py-5">Identity</th><th className="px-6 py-5 text-right">Actions</th></tr>
               </thead>
               <tbody className="divide-y divide-slate-800">
                 {filteredParticipants.map(p => (
                   <tr key={p.id} className={`${getStatusRowClass(p)} transition-all group`}>
                     <td className="px-6 py-4"><div><p className="font-bold text-white">{p.name}</p><p className="text-[10px] text-slate-500">ID: {p.id}</p></div></td>
                     <td className="px-6 py-4 text-right flex justify-end gap-2">
                        <button onClick={() => setStage(db.settings.highlightedParticipantId === p.id ? null : p.id, 'NOW')} className={`px-4 py-2 rounded-full text-[10px] font-black uppercase transition-all ${db.settings.highlightedParticipantId === p.id ? 'bg-orange-600 text-white' : 'text-slate-500 border border-slate-800'}`}>{db.settings.highlightedParticipantId === p.id ? 'Spotlight ON' : 'Spotlight'}</button>
                        <button onClick={() => setEditingParticipant(p)} className="text-orange-500 hover:bg-orange-600 hover:text-white px-4 py-2 rounded-full text-[10px] font-black uppercase border border-orange-500/20">Edit</button>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
          </div>

          {editingParticipant && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-[100] animate-in fade-in duration-300">
              <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] w-full max-w-2xl max-h-[90vh] overflow-y-auto p-10 shadow-2xl relative animate-in zoom-in-95 duration-300">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h2 className="text-4xl font-black brand-font text-white uppercase tracking-wider">Modify Participant</h2>
                    <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mt-1">Unique Identifier: <span className="text-orange-500 font-mono">{editingParticipant.id}</span></p>
                  </div>
                  <button onClick={() => setEditingParticipant(null)} className="text-slate-500 hover:text-white text-3xl transition-colors">&times;</button>
                </div>

                <form onSubmit={handleUpdateParticipant} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-[10px] text-slate-500 uppercase font-black tracking-widest block mb-2">Full Name</label>
                      <input 
                        className="w-full bg-slate-800 border border-slate-700 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-orange-500 shadow-inner"
                        value={editingParticipant.name}
                        onChange={e => setEditingParticipant({...editingParticipant, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 uppercase font-black tracking-widest block mb-2">Phone Number</label>
                      <input 
                        className="w-full bg-slate-800 border border-slate-700 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-orange-500 shadow-inner"
                        value={editingParticipant.phoneNumber}
                        onChange={e => setEditingParticipant({...editingParticipant, phoneNumber: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-[10px] text-slate-500 uppercase font-black tracking-widest block mb-2">Competition Category</label>
                      <select 
                        className="w-full bg-slate-800 border border-slate-700 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-orange-500 appearance-none cursor-pointer shadow-inner"
                        value={editingParticipant.category}
                        onChange={e => setEditingParticipant({...editingParticipant, category: e.target.value})}
                      >
                        {db.settings.categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 uppercase font-black tracking-widest block mb-2">Performer Status</label>
                      <select 
                        className="w-full bg-slate-800 border border-slate-700 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-orange-500 appearance-none cursor-pointer shadow-inner"
                        value={editingParticipant.status}
                        onChange={e => setEditingParticipant({...editingParticipant, status: e.target.value as any})}
                      >
                        <option value="PENDING">PENDING</option>
                        <option value="ON_STAGE">ON STAGE</option>
                        <option value="COMPLETED">COMPLETED</option>
                        <option value="DISQUALIFIED">DISQUALIFIED</option>
                      </select>
                    </div>
                  </div>

                  <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800 space-y-4">
                    <h3 className="text-[10px] text-slate-600 uppercase font-black tracking-[0.2em] border-b border-slate-900 pb-2">Custom Registration Data</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      {db.settings.registrationFields.map(field => (
                        <div key={field.id}>
                          <label className="text-[10px] text-slate-700 uppercase font-bold tracking-tighter block mb-1">{field.label}</label>
                          <input 
                            className="w-full bg-slate-900 border border-slate-800 p-3 rounded-xl text-xs text-white outline-none focus:border-slate-600 transition-all"
                            value={editingParticipant.customData[field.id] || ''}
                            onChange={e => {
                              const newData = { ...editingParticipant.customData, [field.id]: e.target.value };
                              setEditingParticipant({ ...editingParticipant, customData: newData });
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button type="submit" className="flex-1 bg-orange-600 hover:bg-orange-700 text-white font-black py-4 rounded-2xl text-sm uppercase tracking-widest shadow-xl shadow-orange-500/20 transition-all">Save Changes</button>
                    <button type="button" onClick={() => setEditingParticipant(null)} className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-400 font-bold py-4 rounded-2xl text-sm uppercase tracking-widest transition-all">Discard</button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'EVENTS' && (
        <div className="space-y-6">
           <div className="flex justify-between items-center">
             <h3 className="text-2xl font-black brand-font text-white uppercase tracking-widest">Event Assets</h3>
             <button onClick={addEvent} className="bg-orange-600 px-6 py-3 rounded-2xl text-xs font-black uppercase text-white shadow-xl shadow-orange-500/20">+ New Event</button>
           </div>
           
           <div className="grid gap-6">
             {db.events.map(ev => (
               <div key={ev.id} className={`bg-slate-900 p-8 rounded-[2.5rem] border-2 transition-all ${ev.isPrimary ? 'border-orange-500 shadow-xl' : 'border-slate-800'}`}>
                 <div className="grid md:grid-cols-2 gap-8">
                   <div className="space-y-4">
                     <input className="text-2xl font-black brand-font bg-transparent border-b border-slate-800 focus:border-orange-500 text-white outline-none w-full" value={ev.title} onChange={e => updateEventField(ev.id, 'title', e.target.value)} />
                     <textarea className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-300 outline-none focus:border-orange-500 min-h-[100px]" placeholder="Ad content..." value={ev.adText} onChange={e => updateEventField(ev.id, 'adText', e.target.value)} />
                     <div className="flex flex-col gap-2">
                       <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Event Media</label>
                       <div className="flex gap-2">
                         <select className="bg-slate-950 border border-slate-800 p-2 rounded-xl text-xs text-white" value={ev.mediaType} onChange={e => updateEventField(ev.id, 'mediaType', e.target.value)}>
                            <option value="NONE">None</option>
                            <option value="IMAGE">Image</option>
                            <option value="VIDEO">Video (YouTube/MP4)</option>
                         </select>
                         <input className="flex-1 bg-slate-950 border border-slate-800 p-2 rounded-xl text-xs text-white outline-none" placeholder="Media URL or Source" value={ev.mediaUrl} onChange={e => updateEventField(ev.id, 'mediaUrl', e.target.value)} />
                       </div>
                       {ev.mediaType === 'IMAGE' && (
                         <div className="mt-2">
                            <label className="bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg text-[10px] font-black uppercase cursor-pointer transition-all inline-block">
                              Upload Image
                              <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(ev.id, e)} />
                            </label>
                            {ev.mediaUrl && <img src={ev.mediaUrl} className="mt-2 h-20 w-auto rounded border border-slate-800" alt="Preview" />}
                         </div>
                       )}
                     </div>
                   </div>
                   
                   <div className="space-y-4 flex flex-col justify-between">
                      <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
                        <div className="flex justify-between items-center"><span className="text-xs font-bold text-slate-400">Show Ad</span><button onClick={() => toggleEventActive(ev.id, 'isAdActive')} className={`w-10 h-5 rounded-full relative transition-all ${ev.isAdActive ? 'bg-orange-600' : 'bg-slate-800'}`}><div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${ev.isAdActive ? 'right-1' : 'left-1'}`} /></button></div>
                        <div className="flex justify-between items-center"><span className="text-xs font-bold text-slate-400">Countdown</span><button onClick={() => toggleEventActive(ev.id, 'isCountdownActive')} className={`w-10 h-5 rounded-full relative transition-all ${ev.isCountdownActive ? 'bg-orange-600' : 'bg-slate-800'}`}><div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${ev.isCountdownActive ? 'right-1' : 'left-1'}`} /></button></div>
                        <input type="datetime-local" className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs text-white" value={ev.eventDate.split('.')[0]} onChange={e => updateEventField(ev.id, 'eventDate', new Date(e.target.value).toISOString())} />
                      </div>
                      <div className="flex gap-2">
                        {!ev.isPrimary && <button onClick={() => toggleEventActive(ev.id, 'isPrimary')} className="flex-1 py-3 bg-slate-800 text-white rounded-xl text-[10px] font-black uppercase hover:bg-orange-600 transition-all">Set Primary</button>}
                        <button onClick={() => deleteEvent(ev.id)} className="px-4 py-3 bg-red-950/30 text-red-500 rounded-xl text-[10px] font-black uppercase hover:bg-red-600 hover:text-white transition-all">Delete</button>
                      </div>
                   </div>
                 </div>
               </div>
             ))}
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
