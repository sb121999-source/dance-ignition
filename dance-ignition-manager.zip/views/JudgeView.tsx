
import React, { useState, useMemo, useEffect } from 'react';
import { DB, Judge, Participant } from '../types';

interface JudgeViewProps {
  db: DB;
  setDb: (newDb: Partial<DB>) => void;
  currentJudge: Judge;
}

const JudgeView: React.FC<JudgeViewProps> = ({ db, setDb, currentJudge }) => {
  const [searchCode, setSearchCode] = useState('');
  const [currentScores, setCurrentScores] = useState<Record<string, number>>({});
  const [remarks, setRemarks] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [justSubmitted, setJustSubmitted] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const activeParticipant = useMemo(() => {
    const id = selectedId || db.settings.highlightedParticipantId;
    return db.participants.find(p => p.id === id) || null;
  }, [selectedId, db.settings.highlightedParticipantId, db.participants]);

  const judgeSubmission = useMemo(() => {
    return activeParticipant?.submissions.find(s => s.judgeId === currentJudge.id);
  }, [activeParticipant, currentJudge.id]);

  const hasSubmitted = !!judgeSubmission;
  // Final check to see if we should allow interaction
  const canEdit = !hasSubmitted || isEditing;

  // Sync state when participant changes or submission updates
  useEffect(() => {
    setJustSubmitted(false);
    setIsEditing(false); // Reset editing mode on participant switch
    if (judgeSubmission) {
      setCurrentScores(judgeSubmission.scores);
      setRemarks(judgeSubmission.remarks);
    } else {
      setCurrentScores({});
      setRemarks('');
    }
  }, [activeParticipant?.id, judgeSubmission]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeParticipant) return;

    const newSubmissions = activeParticipant.submissions.filter(s => s.judgeId !== currentJudge.id);
    newSubmissions.push({
      judgeId: currentJudge.id,
      scores: currentScores,
      remarks,
      timestamp: Date.now()
    });

    const updatedParticipants = db.participants.map(p => 
      p.id === activeParticipant.id 
        ? { ...p, submissions: newSubmissions, status: 'COMPLETED' as const }
        : p
    );

    setDb({ participants: updatedParticipants });
    setJustSubmitted(true);
    setIsEditing(false); // Lock it back after submission
  };

  const handleManualSearch = () => {
    const p = db.participants.find(p => p.id === searchCode.toUpperCase());
    if (p) {
      setSelectedId(p.id);
      setSearchCode('');
    } else {
      alert("Participant not found");
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-8 animate-in fade-in duration-500">
      {/* Left Column: List & Search */}
      <div className="space-y-6">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold brand-font text-white">Find Participant</h2>
            {selectedId && (
              <button 
                onClick={() => setSelectedId(null)} 
                className="text-[10px] font-black text-orange-500 hover:underline uppercase tracking-tighter"
              >
                Follow Stage
              </button>
            )}
          </div>
          <div className="flex gap-2 mb-6">
            <input 
              className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 outline-none uppercase font-mono text-sm focus:ring-1 ring-orange-500 transition-all text-white"
              placeholder="Unique Code"
              value={searchCode}
              onChange={e => setSearchCode(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleManualSearch()}
            />
            <button onClick={handleManualSearch} className="bg-orange-600 hover:bg-orange-700 text-white px-4 rounded-lg text-xs font-bold transition-colors">Search</button>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Performers Pool</h3>
            <div className="max-h-[500px] overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              {db.participants.map(p => {
                const isActive = activeParticipant?.id === p.id;
                const isHighlight = db.settings.highlightedParticipantId === p.id;
                const gradedByMe = p.submissions.some(s => s.judgeId === currentJudge.id);
                
                return (
                  <button 
                    key={p.id}
                    onClick={() => setSelectedId(p.id)}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 relative overflow-hidden group ${
                      isActive ? 'border-orange-500 bg-orange-500/10 shadow-lg shadow-orange-500/5' : 'border-slate-800 bg-slate-800/50 hover:bg-slate-800 hover:border-slate-600'
                    }`}
                  >
                    {isHighlight && (
                      <div className="absolute top-0 right-0 h-full w-1 bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]"></div>
                    )}
                    <div className="text-left relative z-10">
                      <div className="flex items-center gap-2">
                        <p className={`font-bold text-sm ${isActive ? 'text-white' : 'text-slate-300'}`}>{p.name}</p>
                        {isHighlight && (
                          <div className="bg-orange-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded shadow-sm animate-pulse uppercase tracking-tighter">Live Stage</div>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono font-bold">{p.id} • {p.category}</p>
                    </div>
                    <div className="relative z-10">
                      {gradedByMe ? (
                        <div className="flex items-center gap-1.5 bg-green-600/20 px-2 py-1 rounded-lg border border-green-500/30">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                          <span className="text-green-500 text-[9px] font-black tracking-tighter uppercase">Graded</span>
                        </div>
                      ) : (
                        <span className="text-slate-600 text-[10px] font-bold uppercase px-2">Pending</span>
                      )}
                    </div>
                  </button>
                );
              })}
              {db.participants.length === 0 && (
                <p className="text-center text-slate-600 py-8 italic text-sm">No performers registered yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Center/Right Column: Scoring Tool */}
      <div className="lg:col-span-2 space-y-6">
        {activeParticipant ? (
          <div className="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem] shadow-2xl animate-in slide-in-from-right-4 duration-500 relative overflow-hidden">
            {hasSubmitted && !isEditing && (
              <div className="absolute top-0 right-0 bg-green-600 text-white px-8 py-2 font-black text-[10px] tracking-widest uppercase rotate-45 transform translate-x-6 translate-y-2 shadow-lg z-10 border-b-2 border-white/20">
                GRADED ✓
              </div>
            )}
            
            {(hasSubmitted || justSubmitted) && !isEditing && (
              <div className="mb-8 p-6 bg-green-500/10 border-2 border-green-500/30 rounded-3xl flex items-center gap-4 animate-in fade-in slide-in-from-top-4 duration-500">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white text-xl font-black shadow-lg shadow-green-500/20">✓</div>
                <div className="flex-1">
                  <h4 className="text-green-500 font-black brand-font text-2xl tracking-wider uppercase leading-tight">Evaluation Logged</h4>
                  <p className="text-xs text-green-500/70 font-medium">
                    Submission recorded on {new Date(judgeSubmission?.timestamp || Date.now()).toLocaleString()}
                  </p>
                </div>
                {db.settings.allowJudgeEdits ? (
                  <div>
                    <button 
                      onClick={() => setIsEditing(true)}
                      className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-xl text-xs font-black uppercase tracking-widest transition-all"
                    >
                      Edit Score
                    </button>
                  </div>
                ) : (
                  <div className="text-right">
                    <span className="text-[10px] font-black text-slate-600 uppercase tracking-tighter italic">Scores Locked by Admin</span>
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-between items-start mb-10 border-b border-slate-800 pb-8">
              <div>
                <p className="text-[10px] font-black text-orange-500 uppercase tracking-widest mb-2">
                  {isEditing ? 'Re-evaluating Performance' : 'Live Evaluation In Progress'}
                </p>
                <h2 className="text-5xl font-black brand-font text-white leading-none">{activeParticipant.name}</h2>
                <div className="flex gap-3 mt-4">
                  <span className="text-[10px] px-3 py-1 bg-slate-800 rounded-full border border-slate-700 font-bold text-slate-400 uppercase tracking-wider">{activeParticipant.category}</span>
                  <span className="text-[10px] px-3 py-1 bg-slate-800 rounded-full border border-slate-700 font-mono font-black text-orange-600">ID: {activeParticipant.id}</span>
                </div>
              </div>
              <div className="text-right bg-slate-950 px-6 py-4 rounded-2xl border border-slate-800 shadow-inner">
                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Assigned Judge</p>
                <p className="font-bold text-white text-sm">{currentJudge.name}</p>
                <div className="mt-1 h-1 w-full bg-orange-600/20 rounded-full overflow-hidden">
                  <div className="h-full bg-orange-600 w-full animate-pulse"></div>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-12">
              <div className="grid md:grid-cols-2 gap-x-12 gap-y-10">
                {db.settings.subjects.map(sub => (
                  <div key={sub.id} className={`space-y-5 transition-all duration-300 ${!canEdit ? 'opacity-80' : ''}`}>
                    <div className="flex justify-between items-end">
                      <label className="text-sm font-black text-slate-300 uppercase tracking-widest">{sub.name}</label>
                      <div className="flex flex-col items-end">
                        <span className={`text-4xl font-black brand-font leading-none ${!canEdit ? 'text-green-500' : 'text-orange-500'}`}>
                          {(currentScores[sub.id] || 0).toFixed(1)}
                        </span>
                        <span className="text-[10px] text-slate-600 font-bold uppercase">MAX {sub.maxScore}</span>
                      </div>
                    </div>
                    <div className="relative pt-1">
                      <input 
                        type="range"
                        min="0"
                        max={sub.maxScore}
                        step="0.1"
                        disabled={!canEdit}
                        className={`w-full h-3 bg-slate-800 rounded-full appearance-none transition-all border border-slate-700 ${!canEdit ? 'cursor-not-allowed opacity-50' : 'cursor-pointer accent-orange-500 hover:accent-orange-400'}`}
                        value={currentScores[sub.id] || 0}
                        onChange={e => setCurrentScores({...currentScores, [sub.id]: parseFloat(e.target.value)})}
                      />
                      <div className="flex justify-between px-1 mt-3">
                         <span className="text-[8px] font-black text-slate-700 uppercase">Needs Improvement</span>
                         <span className="text-[8px] font-black text-slate-700 uppercase">Excellent</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className={`pt-8 border-t border-slate-800 transition-all duration-300 ${!canEdit ? 'opacity-80' : ''}`}>
                <label className="block text-xs font-black text-slate-500 mb-4 uppercase tracking-[0.2em]">Juror Remarks & Feedback</label>
                <textarea 
                  disabled={!canEdit}
                  className={`w-full bg-slate-950 border border-slate-800 rounded-3xl p-6 min-h-[160px] outline-none text-slate-200 placeholder:text-slate-700 shadow-inner transition-all ${!canEdit ? 'cursor-not-allowed opacity-50' : 'focus:ring-2 ring-orange-500/50 focus:border-orange-500/50'}`}
                  placeholder="Analyze the performance... technicality, artistry, transition, and overall impact."
                  value={remarks}
                  onChange={e => setRemarks(e.target.value)}
                />
              </div>

              <div className="flex justify-end pt-4 gap-4">
                {isEditing && (
                  <button 
                    type="button"
                    onClick={() => {
                      setIsEditing(false);
                      // Reset to what's in the DB
                      if (judgeSubmission) {
                        setCurrentScores(judgeSubmission.scores);
                        setRemarks(judgeSubmission.remarks);
                      }
                    }}
                    className="w-full md:w-auto px-10 py-5 font-black rounded-[2rem] text-lg brand-font text-slate-400 hover:text-white transition-all uppercase tracking-widest"
                  >
                    Cancel Edit
                  </button>
                )}
                <button 
                  type="submit"
                  disabled={!canEdit}
                  className={`w-full md:w-auto px-16 py-5 font-black rounded-[2rem] text-2xl brand-font shadow-2xl transition-all uppercase tracking-widest ${
                    !canEdit 
                    ? 'bg-green-600/20 text-green-500 border-2 border-green-500/30 cursor-not-allowed' 
                    : 'bg-orange-600 hover:bg-orange-700 text-white shadow-orange-500/30 hover:scale-[1.02] active:scale-95'
                  }`}
                >
                  {!hasSubmitted ? 'Finalize & Submit Scores' : isEditing ? 'Update & Save Changes' : 'Evaluation Locked ✓'}
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="h-full min-h-[500px] flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-[3rem] p-16 text-center bg-slate-900/30 animate-in fade-in duration-1000">
            <div className="w-24 h-24 bg-slate-800 rounded-[2rem] flex items-center justify-center mb-8 shadow-2xl relative">
              <div className="absolute inset-0 bg-orange-600/10 rounded-[2rem] animate-ping"></div>
              <svg className="w-12 h-12 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
            </div>
            <h2 className="text-4xl font-black text-slate-400 brand-font tracking-tight mb-4 uppercase">Waiting for Spotlight</h2>
            <p className="text-slate-600 max-w-sm mt-2 font-medium">The production desk will highlight the next performer when ready. You can also manually search for a specific participant code using the sidebar.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default JudgeView;
