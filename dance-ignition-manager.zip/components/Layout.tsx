
import React from 'react';
import { UserRole } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  role: UserRole;
  onLogout: () => void;
  title: string;
}

const Layout: React.FC<LayoutProps> = ({ children, role, onLogout, title }) => {
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Decorative gradients */}
      <div className="fixed top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-600 via-purple-600 to-orange-600 z-[100]"></div>
      
      <header className="glass sticky top-0 z-50 border-b border-white/5 h-20">
        <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
          <div className="flex items-center gap-4 group cursor-pointer">
            <div className="w-12 h-12 btn-primary rounded-xl flex items-center justify-center font-bold text-2xl brand-font italic text-white shadow-2xl group-hover:rotate-12 transition-transform">DI</div>
            <div className="hidden md:block">
              <h1 className="text-2xl brand-font tracking-[0.2em] text-white leading-none uppercase">{title}</h1>
              <p className="text-[8px] font-black text-orange-500 uppercase tracking-[0.5em] mt-1">Official Manager</p>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <span className={`text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-full border shadow-sm ${
                role === 'ADMIN' ? 'bg-orange-600/10 border-orange-500/30 text-orange-500' :
                role === 'JUDGE' ? 'bg-purple-600/10 border-purple-500/30 text-purple-500' :
                'bg-slate-800/50 border-slate-700 text-slate-500'
              }`}>
                {role} Mode
              </span>
              {role !== 'PUBLIC' && (
                <button 
                  onClick={onLogout}
                  className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-white transition-colors hover:underline"
                >
                  Exit Session
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6 md:p-8 relative z-10">
        {children}
      </main>

      <footer className="bg-slate-950/80 border-t border-white/5 py-12 mt-20 relative z-10">
        <div className="max-w-7xl mx-auto px-6 text-center space-y-4">
          <div className="brand-font text-3xl text-slate-800 select-none">DANCE IGNITION</div>
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.4em]">
            © {new Date().getFullYear()} {title}. Unleash the Energy.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
