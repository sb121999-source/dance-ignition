
export type UserRole = 'PUBLIC' | 'JUDGE' | 'ADMIN';

export interface Subject {
  id: string;
  name: string;
  maxScore: number;
}

export interface ScoreSubmission {
  judgeId: string;
  scores: Record<string, number>; // subjectId -> score
  remarks: string;
  timestamp: number;
}

export interface Participant {
  id: string; // unique code
  name: string;
  phoneNumber: string;
  category: string;
  ageGroup: string;
  status: 'PENDING' | 'ON_STAGE' | 'COMPLETED' | 'DISQUALIFIED';
  submissions: ScoreSubmission[];
  registrationDate: number;
  customData: Record<string, string>; // Store dynamic field values
}

export interface Judge {
  id: string;
  name: string;
  pin: string;
}

export interface CompetitionEvent {
  id: string;
  title: string;
  adText: string;
  eventDate: string;
  isAdActive: boolean;
  isCountdownActive: boolean;
  isPrimary: boolean; // Only one primary event shows on the home page
  mediaType: 'NONE' | 'IMAGE' | 'VIDEO';
  mediaUrl: string; // Can be a URL or a base64 string
}

export interface CompetitionSettings {
  websiteName: string;
  season: string;
  scoringFormula: 'SUM' | 'AVERAGE' | 'WEIGHTED AVERAGE' | 'HIGHEST SCORE';
  subjectWeights: Record<string, number>; // subjectId -> weight
  highlightedParticipantId: string | null;
  nextParticipantId: string | null;
  subjects: Subject[];
  categories: string[];
  registrationFields: {
    id: string;
    label: string;
    required: boolean;
    type: 'text' | 'tel' | 'number';
  }[];
  allowJudgeEdits: boolean; 
  showPublicLeaderboard: boolean;
  showParticipantsTab: boolean; // Extra toggle
  showResultsTab: boolean; // Extra toggle
}

export interface WinnerArchive {
  year: string;
  prizeDetails: string; 
  winners: {
    category: string;
    name: string;
    rank: number;
  }[];
}

export interface DB {
  participants: Participant[];
  judges: Judge[];
  settings: CompetitionSettings;
  archives: WinnerArchive[];
  events: CompetitionEvent[]; // New collection for event management
}
