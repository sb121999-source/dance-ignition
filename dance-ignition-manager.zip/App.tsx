
import React, { useState, useEffect, useMemo } from 'react';
import { GoogleGenAI } from "@google/genai";
import { UserRole, Participant, Judge, CompetitionSettings, DB } from './types';
import { getDB, saveDB } from './store';
import Layout from './components/Layout';
import PublicView from './views/PublicView';
import JudgeView from './views/JudgeView';
import AdminView from './views/AdminView';
import Login from './views/Login';

const App: React.FC = () => {
  const [role, setRole] = useState<UserRole>('PUBLIC');
  const [db, setDb] = useState<DB>(getDB());
  const [currentJudge, setCurrentJudge] = useState<Judge | null>(null);

  // Sync state to local storage whenever it changes
  useEffect(() => {
    saveDB(db);
  }, [db]);

  const handleLogin = (newRole: UserRole, user?: Judge) => {
    setRole(newRole);
    if (user) setCurrentJudge(user);
  };

  const handleLogout = () => {
    setRole('PUBLIC');
    setCurrentJudge(null);
  };

  const updateDb = (newDb: Partial<DB>) => {
    setDb(prev => ({ ...prev, ...newDb }));
  };

  // Find the primary event to display advertisements if active
  const primaryEvent = useMemo(() => db.events.find(e => e.isPrimary) || null, [db.events]);

  const renderView = () => {
    switch (role) {
      case 'ADMIN':
        return <AdminView db={db} setDb={updateDb} />;
      case 'JUDGE':
        return <JudgeView db={db} setDb={updateDb} currentJudge={currentJudge!} />;
      default:
        return (
          <div className="space-y-8">
            <div className="flex justify-end gap-2">
              <button 
                onClick={() => setRole('JUDGE' as any)} // For UI navigation to login
                className="text-xs text-slate-500 hover:text-orange-500"
              >
                Judge Access
              </button>
              <button 
                onClick={() => setRole('ADMIN' as any)}
                className="text-xs text-slate-500 hover:text-orange-500"
              >
                Admin Access
              </button>
            </div>
            {/* These "login" states are temporary for the demo until user actually logins */}
            <PublicView db={db} setDb={updateDb} />
          </div>
        );
    }
  };

  // If a role is requested but not authenticated (except public)
  const isLoginPage = (role === 'ADMIN' || role === 'JUDGE') && !currentJudge && role !== 'ADMIN'; 
  // Simplified logic for this demo: Admin has no separate judge object, Judge does.
  // We'll use a local state to handle the Login component.
  
  const [isAuthenticating, setIsAuthenticating] = useState<UserRole | null>(null);

  if (isAuthenticating) {
    return (
      <Login 
        type={isAuthenticating} 
        db={db} 
        onLogin={(r, u) => {
          handleLogin(r, u);
          setIsAuthenticating(null);
        }} 
        onCancel={() => setIsAuthenticating(null)}
      />
    );
  }

  return (
    <Layout 
      role={role} 
      onLogout={handleLogout} 
      title={db.settings.websiteName}
    >
      {role === 'PUBLIC' ? (
        <div className="space-y-6">
          <div className="flex justify-between items-center bg-slate-800/50 p-3 rounded-lg border border-slate-700">
            <div className="flex gap-4">
              <button onClick={() => setIsAuthenticating('JUDGE')} className="text-sm font-medium text-orange-400 hover:underline">Judge Portal</button>
              <button onClick={() => setIsAuthenticating('ADMIN')} className="text-sm font-medium text-slate-400 hover:underline">Admin Console</button>
            </div>
            {/* Fix: Using primaryEvent properties from the events collection instead of non-existent CompetitionSettings properties */}
            {primaryEvent?.isAdActive && (
              <div className="bg-orange-600 px-3 py-1 rounded-full text-xs font-bold animate-pulse">
                AD: {primaryEvent.adText}
              </div>
            )}
          </div>
          <PublicView db={db} setDb={updateDb} />
        </div>
      ) : renderView()}
    </Layout>
  );
};

export default App;
