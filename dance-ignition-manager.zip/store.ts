
import { CompetitionSettings, DB, CompetitionEvent } from './types';

const STORAGE_KEY = 'dance_ignition_db';

const DEFAULT_SETTINGS: CompetitionSettings = {
  websiteName: 'DANCE IGNITION',
  season: 'SEASON 2025',
  scoringFormula: 'SUM',
  subjectWeights: {
    'sub-1': 1,
    'sub-2': 1,
    'sub-3': 1
  },
  highlightedParticipantId: null,
  nextParticipantId: null,
  subjects: [
    { id: 'sub-1', name: 'Technique', maxScore: 10 },
    { id: 'sub-2', name: 'Creativity', maxScore: 10 },
    { id: 'sub-3', name: 'Performance', maxScore: 10 }
  ],
  categories: ['Solo Contemporary', 'Hip Hop Group', 'Folk Fusion', 'Classical Solo'],
  registrationFields: [
    { id: 'field-name', label: 'Full Name', required: true, type: 'text' },
    { id: 'field-phone', label: 'Phone Number', required: true, type: 'tel' },
    { id: 'field-age', label: 'Age Group', required: true, type: 'text' }
  ],
  allowJudgeEdits: true,
  showPublicLeaderboard: true,
  showParticipantsTab: true,
  showResultsTab: true
};

export const getDB = (): DB => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) return { participants: [], judges: [], settings: DEFAULT_SETTINGS, archives: [], events: [] };
  const db = JSON.parse(data);
  
  // Migration
  if (!db.events) db.events = [];
  db.events = db.events.map((ev: any) => ({
    ...ev,
    mediaType: ev.mediaType || 'NONE',
    mediaUrl: ev.mediaUrl || ''
  }));

  if (!db.settings.nextParticipantId) db.settings.nextParticipantId = null;
  if (!db.settings.scoringFormula) db.settings.scoringFormula = 'SUM';
  if (db.settings.allowJudgeEdits === undefined) db.settings.allowJudgeEdits = true;
  if (db.settings.showPublicLeaderboard === undefined) db.settings.showPublicLeaderboard = true;
  if (db.settings.showParticipantsTab === undefined) db.settings.showParticipantsTab = true;
  if (db.settings.showResultsTab === undefined) db.settings.showResultsTab = true;

  return db;
};

export const saveDB = (db: DB) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
};
